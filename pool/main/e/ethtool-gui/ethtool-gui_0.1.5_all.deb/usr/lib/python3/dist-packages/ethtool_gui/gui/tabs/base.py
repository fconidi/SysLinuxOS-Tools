"""Small GTK building blocks for advanced settings."""

from __future__ import annotations

import dataclasses

import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk  # noqa: E402

from ...core.models import Field  # noqa: E402
from ...i18n import translate as _  # noqa: E402

FIELD_LABELS = {
    name: "field_" + name for name in (
        "state", "speed_mbps", "duplex", "autoneg", "supported_modes", "advertised_modes",
        "partner_modes", "port", "transceiver", "mdix", "wol_supported", "wol_current",
        "driver", "version", "firmware_version", "bus_info", "supports_test", "supports_eeprom",
        "supports_register_dump", "supports_statistics", "values", "supported", "reason",
        "enabled", "active", "tx_lpi_us", "current", "supported_flag", "raw", "indirection",
        "hash_key", "identifier", "vendor", "part", "readings", "alarm_flags", "name",
        "value", "unit", "warn_low", "alarm_low", "warn_high", "alarm_high", "threshold_unit",
    )
}


def scroll(widget: Gtk.Widget) -> Gtk.ScrolledWindow:
    box = Gtk.ScrolledWindow(hscrollbar_policy=Gtk.PolicyType.AUTOMATIC,
                            vscrollbar_policy=Gtk.PolicyType.AUTOMATIC)
    box.add(widget)
    return box


def label(text: str, *, selectable: bool = False) -> Gtk.Label:
    return Gtk.Label(label=text, xalign=0, yalign=0, wrap=True, selectable=selectable)


class Topic(Gtk.Box):
    def __init__(self) -> None:
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=10, margin=12)
        self.iface: str | None = None
        self.reason = label("")
        self.pack_start(self.reason, False, False, 0)

    def show_interface(self, iface: str | None) -> None:
        self.iface = iface
        self.reason.set_text("")

    def unavailable(self, reason: str | None) -> None:
        self.reason.set_text(_("unavailable") if reason is None else reason)


class TextTab(Topic):
    def __init__(self, reader=None, helper_call=None, what: str | None = None) -> None:
        super().__init__()
        self.reader = reader
        self.helper_call, self.what = helper_call, what
        self.authorize_button = Gtk.Button(label=_("read_with_authorization"))
        self.authorize_button.set_no_show_all(True)
        self.authorize_button.connect("clicked", self._authorized_read)
        self.pack_start(self.authorize_button, False, False, 0)
        self.output = Gtk.TextView(editable=False, cursor_visible=False, monospace=True, wrap_mode=Gtk.WrapMode.WORD_CHAR)
        self.pack_start(scroll(self.output), True, True, 0)

    def load(self, iface: str):
        return self.reader(iface) if self.reader else None

    def render(self, data) -> None:
        reason = getattr(data, "reason", None) if getattr(data, "supported", True) is False else None
        if isinstance(data, dict):
            reason = next((getattr(value, "reason", None) for key, value in data.items()
                           if key.lower() == self.what and getattr(value, "supported", True) is False and
                           getattr(value, "reason", None) and
                           any(word in value.reason.lower() for word in ("permission", "not permitted"))), None)
        if reason:
            self.unavailable(reason)
        else:
            self.unavailable("")
        self.output.get_buffer().set_text(format_data(data))
        if reason and any(word in reason.lower() for word in ("permission", "not permitted")) \
                and self.helper_call and self.what:
            self.authorize_button.show()
        else:
            self.authorize_button.hide()

    def _authorized_read(self, *_args) -> None:
        if not self.iface or not self.helper_call or not self.what:
            return
        from ..common import thread_runner
        thread_runner(lambda: self.helper_call("read", iface=self.iface, what=self.what),
                      lambda reply, error: self.unavailable(str(error)) if error
                      else self.output.get_buffer().set_text(format_data(reply.get("data"))))


def format_data(data) -> str:
    if isinstance(data, Field):
        return format_data(data.value) if data.supported else (data.reason or _("unavailable"))
    if dataclasses.is_dataclass(data):
        lines = []
        for field in dataclasses.fields(data):
            value = getattr(data, field.name)
            if value is None or isinstance(value, Field) and value.value is None and value.supported:
                continue
            caption = _(FIELD_LABELS[field.name]) if field.name in FIELD_LABELS else field.name.replace("_", " ").title()
            lines.append(f"{caption}: {format_data(value)}")
        return "\n".join(lines)
    if isinstance(data, dict):
        return "\n".join(f"{key}: {format_data(value)}" for key, value in data.items())
    if isinstance(data, (list, tuple)):
        return "\n".join(format_data(value) for value in data)
    if isinstance(data, bool):
        return _("yes") if data else _("no")
    return "" if data is None else str(data)
