import json
from abc import ABC, abstractmethod
from dataclasses import dataclass, field

import requests

TOOL_SPECS = [
    {
        "name": "run_readonly",
        "description": "Execute a read-only diagnostic command and return its output.",
        "parameters": {
            "type": "object",
            "properties": {"cmd": {"type": "string", "description": "The full command line to run."}},
            "required": ["cmd"],
        },
    },
    {
        "name": "propose_command",
        "description": (
            "Propose a command that changes system state. It is never executed "
            "automatically — the user is shown the command and must confirm it."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "cmd": {"type": "string"},
                "reason": {"type": "string", "description": "Why this command is being proposed."},
            },
            "required": ["cmd", "reason"],
        },
    },
]


@dataclass
class ToolCall:
    name: str
    arguments: dict
    id: str


def _coerce_tool_arguments(raw) -> dict:
    """Normalize tool-call arguments to a dict.

    They arrive as a JSON string (Ollama/OpenAI shape) or as an
    already-decoded object (Anthropic shape), and a model is perfectly capable
    of emitting a truncated or malformed JSON blob. Falling back to an empty
    dict keeps chat() from raising: the empty dict fails loop.py's argument
    validation, which feeds a descriptive error back to the model, instead of
    a json.JSONDecodeError taking down the whole CLI."""
    if isinstance(raw, str):
        try:
            raw = json.loads(raw)
        except ValueError:
            return {}
    return raw if isinstance(raw, dict) else {}


@dataclass
class Turn:
    role: str  # "system" | "user" | "assistant" | "tool"
    content: str = ""
    tool_calls: list[ToolCall] = field(default_factory=list)
    tool_call_id: str = ""
    name: str = ""


@dataclass
class ChatResponse:
    text: str | None
    tool_calls: list[ToolCall]


class ChatBackend(ABC):
    @abstractmethod
    def chat(self, turns: list[Turn], tools: list[dict]) -> ChatResponse:
        raise NotImplementedError


class OllamaBackend(ChatBackend):
    def __init__(self, host: str, model: str):
        self.host = host.rstrip("/")
        self.model = model

    def _to_openai_messages(self, turns: list[Turn]) -> list[dict]:
        messages = []
        for turn in turns:
            if turn.role == "assistant" and turn.tool_calls:
                messages.append(
                    {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [
                            {
                                "id": tc.id,
                                "type": "function",
                                "function": {"name": tc.name, "arguments": json.dumps(tc.arguments)},
                            }
                            for tc in turn.tool_calls
                        ],
                    }
                )
            elif turn.role == "tool":
                messages.append({"role": "tool", "tool_call_id": turn.tool_call_id, "content": turn.content})
            else:
                messages.append({"role": turn.role, "content": turn.content})
        return messages

    def chat(self, turns: list[Turn], tools: list[dict]) -> ChatResponse:
        payload = {
            "model": self.model,
            "messages": self._to_openai_messages(turns),
            "tools": [{"type": "function", "function": spec} for spec in tools],
        }
        response = requests.post(f"{self.host}/v1/chat/completions", json=payload, timeout=120)
        response.raise_for_status()
        data = response.json()
        message = data["choices"][0]["message"]

        raw_tool_calls = message.get("tool_calls") or []
        tool_calls = [
            ToolCall(
                name=tc["function"]["name"],
                arguments=_coerce_tool_arguments(tc["function"].get("arguments")),
                id=tc["id"],
            )
            for tc in raw_tool_calls
        ]

        return ChatResponse(text=message.get("content"), tool_calls=tool_calls)


class AnthropicBackend(ChatBackend):
    API_URL = "https://api.anthropic.com/v1/messages"

    def __init__(self, api_key: str, model: str):
        self.api_key = api_key
        self.model = model

    def _split_system_and_messages(self, turns: list[Turn]) -> tuple[str, list[dict]]:
        system_parts = [t.content for t in turns if t.role == "system"]
        messages = []
        for turn in turns:
            if turn.role == "system":
                continue
            if turn.role == "assistant" and turn.tool_calls:
                messages.append(
                    {
                        "role": "assistant",
                        "content": [
                            {"type": "tool_use", "id": tc.id, "name": tc.name, "input": tc.arguments}
                            for tc in turn.tool_calls
                        ],
                    }
                )
            elif turn.role == "tool":
                messages.append(
                    {
                        "role": "user",
                        "content": [
                            {"type": "tool_result", "tool_use_id": turn.tool_call_id, "content": turn.content}
                        ],
                    }
                )
            else:
                messages.append({"role": turn.role, "content": turn.content})
        return "\n".join(system_parts), messages

    def chat(self, turns: list[Turn], tools: list[dict]) -> ChatResponse:
        system_text, messages = self._split_system_and_messages(turns)
        payload = {
            "model": self.model,
            "max_tokens": 1024,
            "system": system_text,
            "messages": messages,
            "tools": [
                {"name": spec["name"], "description": spec["description"], "input_schema": spec["parameters"]}
                for spec in tools
            ],
        }
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        response = requests.post(self.API_URL, headers=headers, json=payload, timeout=120)
        response.raise_for_status()
        data = response.json()

        text_blocks = [b["text"] for b in data["content"] if b["type"] == "text"]
        tool_calls = [
            ToolCall(name=b["name"], arguments=_coerce_tool_arguments(b.get("input")), id=b["id"])
            for b in data["content"]
            if b["type"] == "tool_use"
        ]

        return ChatResponse(text="\n".join(text_blocks) if text_blocks else None, tool_calls=tool_calls)
