import os
import tomllib
from dataclasses import dataclass
from pathlib import Path

DEFAULT_CONFIG_TOML = (
    'provider = "ollama"\n'
    'model = "llama3.2:3b"\n'
    'ollama_host = "http://127.0.0.1:11434"\n'
    'api_key = ""\n'
)


@dataclass
class Config:
    provider: str
    model: str
    ollama_host: str
    api_key: str


def _restrict_permissions(cfg_path: Path) -> None:
    """Make the config dir owner-only and the config file owner-read/write.

    Applied on every load, not just on creation: this file can hold a
    plaintext cloud API key, and a file created by an earlier version (or by
    hand) under the usual 022 umask is world-readable. Failures are ignored —
    a config we cannot chmod (someone else's, read-only mount) is still a
    config we can read, and refusing to start over it would be worse."""
    for target, mode in ((cfg_path.parent, 0o700), (cfg_path, 0o600)):
        try:
            os.chmod(target, mode)
        except OSError:
            pass


def load_config(path: str) -> Config:
    cfg_path = Path(path)
    if not cfg_path.exists():
        cfg_path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        # O_CREAT|O_EXCL with an explicit mode so the key-bearing file is
        # never briefly world-readable between creation and chmod.
        try:
            fd = os.open(cfg_path, os.O_CREAT | os.O_WRONLY | os.O_EXCL, 0o600)
        except FileExistsError:
            pass  # lost a race with another slai process; its content is fine
        else:
            try:
                os.write(fd, DEFAULT_CONFIG_TOML.encode("utf-8"))
            finally:
                os.close(fd)

    _restrict_permissions(cfg_path)

    with cfg_path.open("rb") as f:
        data = tomllib.load(f)

    return Config(
        provider=data["provider"],
        model=data["model"],
        ollama_host=data["ollama_host"],
        api_key=data.get("api_key", ""),
    )
