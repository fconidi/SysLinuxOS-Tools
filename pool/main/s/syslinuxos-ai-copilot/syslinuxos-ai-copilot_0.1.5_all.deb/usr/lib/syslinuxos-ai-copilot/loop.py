from backends import ChatBackend, TOOL_SPECS, Turn
from executor import propose_and_maybe_run, run_readonly

MAX_ITERATIONS = 6

SYSTEM_PROMPT = (
    "You are the SysLinuxOS shell copilot for an experienced sysadmin/network engineer. "
    "Use run_readonly to gather context from the live system. Use propose_command for any "
    "command that changes system state — it will only run if the human explicitly confirms it. "
    "Never assume a state-changing command ran unless you are told it did.\n\n"
    "run_readonly only accepts a single plain command — no pipes (|), no &&, no redirects, "
    "no quotes, no shell operators of any kind. Never pipe to grep/awk/head; run the plain "
    "command and read the full output yourself instead. Allowed commands: "
    "systemctl status/is-active/list-units <unit>, journalctl, ss, df, free, uptime, dmesg, "
    "ps, lsblk, ip a/l/r/n show, snapper list/status/diff, mount, cat /etc/os-release. "
    "If a call comes back 'not permitted', do not guess or give up — retry with a plain "
    "command from that list instead."
)


# tool name -> argument keys that must be present and be non-empty strings
_REQUIRED_ARGUMENTS = {
    "run_readonly": ("cmd",),
    "propose_command": ("cmd", "reason"),
}


def _validate_arguments(name: str, arguments) -> str | None:
    """Return None if the model's tool-call arguments are usable, else a
    description of what is wrong. A model is free to emit a call with a key
    missing, a null where a string belongs, or an empty command; every one of
    those used to reach the executor and raise (KeyError / AttributeError /
    IndexError from subprocess), killing the CLI mid-answer. They are the
    model's mistakes, so they go back to the model as a tool result it can
    read and retry from."""
    if not isinstance(arguments, dict):
        return f"error: tool call {name} arguments must be an object, got {type(arguments).__name__}"

    for key in _REQUIRED_ARGUMENTS[name]:
        if key not in arguments:
            return f"error: tool call {name} is missing required argument '{key}'"
        value = arguments[key]
        if not isinstance(value, str):
            return (
                f"error: tool call {name} argument '{key}' must be a string, "
                f"got {type(value).__name__}"
            )
        if not value.strip():
            return f"error: tool call {name} argument '{key}' must not be empty"

    return None


def _format_result(result) -> str:
    if result.timed_out:
        return "command timed out after 10s"
    return f"exit_code={result.exit_code}\nstdout:\n{result.stdout}\nstderr:\n{result.stderr}"


def _dispatch_tool_call(tool_call, confirm=input) -> str:
    if tool_call.name not in _REQUIRED_ARGUMENTS:
        return f"unknown tool: {tool_call.name}"

    error = _validate_arguments(tool_call.name, tool_call.arguments)
    if error is not None:
        return error

    if tool_call.name == "run_readonly":
        try:
            result = run_readonly(tool_call.arguments["cmd"])
        except PermissionError as exc:
            return f"not permitted: {exc}"
        return _format_result(result)

    try:
        result = propose_and_maybe_run(
            tool_call.arguments["cmd"], tool_call.arguments["reason"], confirm=confirm
        )
    except ValueError as exc:
        return f"rejected: {exc}"
    if result is None:
        return "user declined to run this command"
    return _format_result(result)


def run_copilot_turn(backend: ChatBackend, user_question: str, confirm=input) -> str:
    turns = [Turn(role="system", content=SYSTEM_PROMPT), Turn(role="user", content=user_question)]

    for _ in range(MAX_ITERATIONS):
        response = backend.chat(turns, TOOL_SPECS)

        if not response.tool_calls:
            return response.text or ""

        turns.append(Turn(role="assistant", tool_calls=response.tool_calls))
        for tool_call in response.tool_calls:
            result_text = _dispatch_tool_call(tool_call, confirm)
            turns.append(
                Turn(role="tool", tool_call_id=tool_call.id, name=tool_call.name, content=result_text)
            )

    return "Unable to finish: too many steps were needed to answer this question."
