import subprocess
from dataclasses import dataclass

from whitelist import has_display_unsafe_characters, is_readonly_allowed, tokenize


@dataclass
class CommandResult:
    cmd: str
    exit_code: int | None
    stdout: str
    stderr: str
    timed_out: bool


def _execute(argv: list[str], timeout: int | None) -> CommandResult:
    """Run an already-tokenized command. Takes the argv list rather than the
    command string on purpose: the caller has to tokenize via
    whitelist.tokenize() anyway, and re-splitting the string here would give
    this function its own second opinion on where the token boundaries are —
    which is exactly how an approved command turns into a different one."""
    cmd = " ".join(argv)
    try:
        proc = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return CommandResult(cmd=cmd, exit_code=None, stdout="", stderr="", timed_out=True)

    return CommandResult(
        cmd=cmd,
        exit_code=proc.returncode,
        stdout=proc.stdout,
        stderr=proc.stderr,
        timed_out=False,
    )


def run_readonly(cmd: str, timeout: int = 10) -> CommandResult:
    if not is_readonly_allowed(cmd):
        raise PermissionError(f"Command not permitted by the read-only whitelist: {cmd!r}")
    return _execute(tokenize(cmd), timeout)


def propose_and_maybe_run(cmd: str, reason: str, confirm=input) -> CommandResult | None:
    """Show a state-changing command to the human and run it only on an
    explicit "y". Both arguments come straight from the model, so both are
    validated before anything is printed: a \\r (or any other control
    character) in cmd lets the model paint a harmless-looking command over the
    real one, so the human confirms one thing and another thing executes.
    Raises ValueError on anything unprintable — the caller in loop.py turns
    that into a tool result the model can see, rather than a crash."""
    if not isinstance(cmd, str) or not isinstance(reason, str):
        raise ValueError("propose_command requires 'cmd' and 'reason' to be strings")

    for label, text in (("cmd", cmd), ("reason", reason)):
        if has_display_unsafe_characters(text):
            raise ValueError(
                f"proposed command {label} contains a control character or non-space "
                f"whitespace and cannot be displayed safely: {text!r}"
            )

    argv = tokenize(cmd)
    if not argv:
        raise ValueError("proposed command is empty")

    # repr() so what the terminal shows is guaranteed to be the literal string
    # being judged, even if some future character class slips past the check.
    print(f"\nProposed command (changes system state): {cmd!r}")
    print(f"Reason: {reason}")
    answer = confirm("Run it? [y/N] ").strip().lower()
    if answer != "y":
        return None
    # No timeout: a human is present and can Ctrl-C. SIGKILLing a confirmed
    # apt-get or snapper rollback at the 10s mark is how you get a half-broken
    # dpkg state or a half-finished btrfs operation.
    return _execute(argv, timeout=None)
