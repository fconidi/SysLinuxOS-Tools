import os
import sys

import requests

from backends import AnthropicBackend, ChatBackend, OllamaBackend
from config import Config, load_config
from loop import run_copilot_turn

CONFIG_PATH = os.path.expanduser("~/.config/slai/config.toml")


class ConfigError(Exception):
    pass


def build_backend(cfg: Config) -> ChatBackend:
    if cfg.provider == "ollama":
        return OllamaBackend(host=cfg.ollama_host, model=cfg.model)
    if cfg.provider == "anthropic":
        if not cfg.api_key:
            raise ConfigError(
                f"provider is 'anthropic' but api_key is empty in {CONFIG_PATH} — set it before using slai"
            )
        return AnthropicBackend(api_key=cfg.api_key, model=cfg.model)
    raise ConfigError(f"unknown provider '{cfg.provider}' in {CONFIG_PATH} — expected 'ollama' or 'anthropic'")


def ensure_model_available(cfg: Config) -> None:
    if cfg.provider != "ollama":
        return
    try:
        tags = requests.get(f"{cfg.ollama_host.rstrip('/')}/api/tags", timeout=5).json()
    except requests.exceptions.RequestException:
        print(
            f"error: cannot reach Ollama at {cfg.ollama_host}. "
            "Is it installed and running? Try: sudo syslinuxos-install-extras ai",
            file=sys.stderr,
        )
        raise SystemExit(1)

    have_model = any(m.get("name", "").startswith(cfg.model) for m in tags.get("models", []))
    if have_model:
        return

    print(f"Model '{cfg.model}' not found locally, pulling it now (this may take a while)...")
    pull_resp = requests.post(
        f"{cfg.ollama_host.rstrip('/')}/api/pull", json={"name": cfg.model}, stream=True, timeout=None
    )
    pull_resp.raise_for_status()
    for line in pull_resp.iter_lines():
        if line:
            print(line.decode("utf-8", errors="ignore"))


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print("usage: slai \"<question about the running system>\"", file=sys.stderr)
        return 2

    question = " ".join(argv)

    try:
        cfg = load_config(CONFIG_PATH)
        backend = build_backend(cfg)
    except ConfigError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    try:
        ensure_model_available(cfg)
    except SystemExit as exc:
        return exc.code or 1

    try:
        answer = run_copilot_turn(backend, question)
    except requests.exceptions.RequestException as exc:
        print(f"error: request to {cfg.provider} backend failed: {exc}", file=sys.stderr)
        return 1
    print(answer)
    return 0


if __name__ == "__main__":
    sys.exit(main())
