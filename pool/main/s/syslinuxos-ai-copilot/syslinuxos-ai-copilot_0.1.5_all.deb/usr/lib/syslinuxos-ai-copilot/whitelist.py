import re

# Shell metacharacters, quote/escape characters, and control characters (CR,
# NUL, ESC, and friends). Quotes and backslash are rejected outright — none
# of the whitelisted commands ever need a quoted argument, and allowing them
# would let a token's real content disagree with what a naive .split() (used
# below) sees vs. what a real shell would parse. Deliberately ASCII
# whitespace-only elsewhere in this module (space/tab) so tokenization here
# can never diverge from a real shell's (e.g. non-breaking space tricks).
_UNSAFE_CHARACTERS = re.compile(r"[;&|`$()<>'\"\\\r\n\x00-\x08\x0b-\x1f\x7f]")

# ASCII control characters, excluding tab (\x09) and newline (\x0a) — newline
# is caught by the whitespace rule below instead. Split out from
# _UNSAFE_CHARACTERS so callers that must accept free-form prose (e.g. the
# `reason` displayed next to a proposed state-changing command) can reject
# terminal-control tricks such as a bare \r rewriting the displayed line,
# without also rejecting apostrophes, parentheses and dollar signs.
_CONTROL_CHARACTERS = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")

# Bare command name, not followed immediately by another word character —
# using a lookahead instead of \b so "mount.nfs" or "ps-watcher" (different
# binaries) are rejected instead of matching the whitelisted name's prefix.
_NAME_BOUNDARY = r"(?=[ \t]|$)"


def _is_disallowed_whitespace(ch: str) -> bool:
    """True for any whitespace character other than a literal space or tab.

    Python's bare str.split() splits on the FULL Unicode whitespace class
    (NBSP U+00A0, NEL U+0085, U+2000-U+200A, U+3000, ...), while _tokens()
    below deliberately splits on space/tab only. Every character in the gap
    between those two sets is a tokenization disagreement waiting to happen:
    "journalctl -n5\\xa0--vacuum-time=1s" is ONE opaque token to _tokens()
    (so no dangerous long option is visible to the argument checks) but three
    tokens to str.split(), the third of which deletes the journal. Rejecting
    the whole class outright is the only way the two views can never diverge,
    and no legitimate whitelisted command needs exotic whitespace."""
    return ch.isspace() and ch not in (" ", "\t")


def has_display_unsafe_characters(text) -> bool:
    """True if text contains an ASCII control character or whitespace outside
    plain space/tab — i.e. anything that can make a terminal display one
    command while a tokenizer sees another. Exported for executor.py so the
    confirmation path and the whitelist path always share one character set;
    deliberately narrower than _UNSAFE_CHARACTERS (no shell metacharacters or
    quotes) because it is also applied to free-form English prose."""
    if not isinstance(text, str):
        return True
    if _CONTROL_CHARACTERS.search(text):
        return True
    return any(_is_disallowed_whitespace(ch) for ch in text)


def _tokens(remainder: str) -> list[str]:
    """Split on literal ASCII space/tab only (never the general Unicode
    whitespace class) — a naive .split() also splits on e.g. non-breaking
    space, which neither bash nor shlex.split treats as a separator, and
    could otherwise split a dangerous letter out of a short-option bundle
    into a token that no longer looks like a flag at all."""
    return [tok for tok in re.split(r"[ \t]+", remainder) if tok]


def tokenize(cmd: str) -> list[str]:
    """The single tokenization of a command string, shared by the whitelist
    checks here and by executor.py's subprocess invocation.

    Exported so the executor can never re-split an approved command with bare
    str.split(): two independent tokenizers mean two different argv lists can
    be derived from one string, and only one of them got inspected."""
    return _tokens(cmd.strip())


def _has_dangerous_short_bundle(tokens: list[str], dangerous_letters: set) -> bool:
    """True if any token is a single-dash short-option (bundle) containing
    one of the dangerous letters anywhere in the bundle — closes bundling
    (e.g. "-tK" bundles "-t" and "-K")."""
    for tok in tokens:
        if tok.startswith("-") and not tok.startswith("--") and len(tok) > 1:
            if any(ch in dangerous_letters for ch in tok[1:]):
                return True
    return False


def _has_dangerous_long_opt(tokens: list[str], dangerous_long_opts: list) -> bool:
    """True if any token is `--` and is a prefix of one of the given full
    long-option strings — closes GNU getopt_long abbreviation (e.g. "--rot"
    is accepted by real journalctl as short for "--rotate"). Splits each
    token on "=" first, so the equally common "--flag=value" spelling (e.g.
    "--vacuum-time=1s") is compared as "--flag", not rejected as "longer
    than the flag it is testing against". Conservative: a token that could
    grammatically abbreviate a dangerous flag is treated as dangerous even
    if it would actually be ambiguous with an unrelated flag in the real
    tool — a false rejection only costs a retry, a false allow is a bypass."""
    for tok in tokens:
        if tok.startswith("--") and len(tok) > 2:
            opt_part = tok.split("=", 1)[0]
            for danger in dangerous_long_opts:
                if danger.startswith(opt_part):
                    return True
    return False


def _short_bundle_is_safe(tok: str, safe_letters: set) -> bool:
    """tok is a single-dash bundle like "-tulpn"; safe only if EVERY
    letter in the bundle is in the allowlist. An unrecognized letter —
    including one nobody has thought to add to a denylist yet — fails
    closed, which is the whole point of an allowlist over a denylist."""
    return all(ch in safe_letters for ch in tok[1:])


def _tool_args_are_safe(remainder: str, safe_letters: set, safe_long_opts: set) -> bool:
    """ss/dmesg: every dash-prefixed token must be an exactly-safe short
    bundle or an exact (non-abbreviated) safe long option. Bare positional
    tokens (no leading dash) are left unexamined — ss's filter expressions
    and dmesg's absence of positional args are never a state-mutation
    vector the way ip's "netns exec CMD" or "-batch FILE" are."""
    for tok in _tokens(remainder):
        if tok.startswith("--"):
            if tok.split("=", 1)[0] not in safe_long_opts:
                return False
        elif tok.startswith("-") and len(tok) > 1:
            if not _short_bundle_is_safe(tok, safe_letters):
                return False
    return True


# ss: small, fully enumerable set of read-only display flags. Deliberately
# excludes "K" (--kill), "D" (--diag, arbitrary file overwrite as root —
# missed by round 2's denylist) and anything else not explicitly needed.
_SS_SAFE_LETTERS = set("tulpna46oeismHrx")
_SS_SAFE_LONG_OPTS = {
    "--tcp", "--udp", "--listening", "--all", "--numeric", "--processes",
    "--extended", "--options", "--memory", "--info", "--resolve",
    "--ipv4", "--ipv6", "--raw",
}

# dmesg: same principle. Deliberately excludes "C"/"c" (clear), "n"
# (console level), "D"/"E" (console on/off), and "F"/"K" (--file/
# --kmsg-file, arbitrary file read — also missed by round 2's denylist).
_DMESG_SAFE_LETTERS = set("TxkurHL")
_DMESG_SAFE_LONG_OPTS = {
    "--ctime", "--decode", "--kernel", "--userspace", "--raw", "--human", "--color",
}


def _ss_is_safe(remainder: str) -> bool:
    return _tool_args_are_safe(remainder, _SS_SAFE_LETTERS, _SS_SAFE_LONG_OPTS)


def _dmesg_is_safe(remainder: str) -> bool:
    return _tool_args_are_safe(remainder, _DMESG_SAFE_LETTERS, _DMESG_SAFE_LONG_OPTS)


def _journalctl_is_safe(remainder: str) -> bool:
    tokens = _tokens(remainder)
    if _has_dangerous_short_bundle(tokens, {"D", "M"}):
        return False
    return not _has_dangerous_long_opt(
        tokens,
        [
            "--vacuum-time", "--vacuum-size", "--vacuum-files",
            "--rotate", "--flush", "--setup-keys", "--sync",
            "--relinquish-var", "--smart-relinquish-var", "--update-catalog",
            "--directory", "--machine", "--file", "--root",
        ],
    )


def _systemctl_is_safe(remainder: str) -> bool:
    """status/is-active/list-units are read-only only for as long as they stay
    pointed at the local running host. -M/--machine redirects the query into a
    container, -H/--host makes systemctl spawn ssh to an attacker-named host
    with the caller's keys, and --root/--image point it at an offline system
    tree. None of those are "read-only host status", so they are denied the
    same way journalctl's out-of-scope options are."""
    tokens = _tokens(remainder)
    if _has_dangerous_short_bundle(tokens, {"M", "H"}):
        return False
    return not _has_dangerous_long_opt(tokens, ["--machine", "--host", "--root", "--image"])


def _snapper_is_safe(remainder: str) -> bool:
    """list/status/diff read the local snapper configs; -r/--root repoints the
    whole operation at a different filesystem tree, which is outside the
    read-only-local-status scope these verbs were whitelisted for."""
    tokens = _tokens(remainder)
    if _has_dangerous_short_bundle(tokens, {"r"}):
        return False
    return not _has_dangerous_long_opt(tokens, ["--root"])


# name -> (pattern matching "name" + a whitespace-or-end boundary, optional
# extra safety check run against the remainder of the command after "name")
_BARE_COMMANDS = {
    "journalctl": (re.compile(r"^journalctl" + _NAME_BOUNDARY), _journalctl_is_safe),
    "ss": (re.compile(r"^ss" + _NAME_BOUNDARY), _ss_is_safe),
    "df": (re.compile(r"^df" + _NAME_BOUNDARY), None),
    "free": (re.compile(r"^free" + _NAME_BOUNDARY), None),
    "uptime": (re.compile(r"^uptime" + _NAME_BOUNDARY), None),
    "dmesg": (re.compile(r"^dmesg" + _NAME_BOUNDARY), _dmesg_is_safe),
    "ps": (re.compile(r"^ps" + _NAME_BOUNDARY), None),
    "lsblk": (re.compile(r"^lsblk" + _NAME_BOUNDARY), None),
}

_SYSTEMCTL_PATTERN = re.compile(r"^systemctl[ \t]+(status|is-active|list-units)" + _NAME_BOUNDARY)
_SNAPPER_PATTERN = re.compile(r"^snapper[ \t]+(list|status|diff)" + _NAME_BOUNDARY)
_MOUNT_PATTERN = re.compile(r"^mount[ \t]*$")
_CAT_PATTERN = re.compile(r"^cat[ \t]+/etc/os-release[ \t]*$")

# ip: allowlist of safe display flags only (no free-form "-\S+"), so an
# unlisted flag like "-batch" (which makes iproute2 execute a file of ip
# commands) cannot match no matter what follows it.
_IP_SAFE_FLAGS = (
    r"-4|-6|-s|-stats|-d|-details|-h|-human|-human-readable"
    r"|-o|-oneline|-br|-brief|-j|-json|-p|-pretty|-c|-color|-t|-timestamp|-ts|-tshort"
)
_IP_PATTERN = re.compile(
    r"^ip(?:[ \t]+(?:" + _IP_SAFE_FLAGS + r"))*"
    r"[ \t]+(a|addr|address|l|link|r|route|n|neigh|neighbor|neighbour)"
    r"([ \t]+(show|list|s|l))?[ \t]*$"
)


def is_readonly_allowed(cmd) -> bool:
    """Return True only if cmd is a string with no shell metacharacters,
    quote/escape characters, control characters, or whitespace outside plain
    space/tab (see _is_disallowed_whitespace), and matches a
    whitelisted read-only command exactly enough to rule out different
    binaries, extra arguments that widen the blast radius (e.g. a second
    file to `cat`), or state-mutating flags on an otherwise read-only tool —
    including flags expressed via short-option bundling or GNU long-option
    abbreviation. Never allows chained/injected commands, even if they start
    with a whitelisted prefix."""
    if not isinstance(cmd, str):
        return False
    stripped = cmd.strip()
    if not stripped:
        return False
    if _UNSAFE_CHARACTERS.search(stripped) or has_display_unsafe_characters(stripped):
        return False

    if _MOUNT_PATTERN.match(stripped) or _CAT_PATTERN.match(stripped) or _IP_PATTERN.match(stripped):
        return True

    systemctl_match = _SYSTEMCTL_PATTERN.match(stripped)
    if systemctl_match:
        return _systemctl_is_safe(stripped[systemctl_match.end():])
    snapper_match = _SNAPPER_PATTERN.match(stripped)
    if snapper_match:
        return _snapper_is_safe(stripped[snapper_match.end():])

    for name, (pattern, extra_check) in _BARE_COMMANDS.items():
        if pattern.match(stripped):
            if extra_check is None:
                return True
            return extra_check(stripped[len(name):])

    return False
