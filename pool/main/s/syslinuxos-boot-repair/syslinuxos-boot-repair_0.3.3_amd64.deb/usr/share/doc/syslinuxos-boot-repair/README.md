# SysLinuxOS Boot Repair

Build the package with `bash build-deb.sh` in this directory. On a
SysLinuxOS Live session, copy over `dist/syslinuxos-boot-repair_0.3.3_amd64.deb`
and install it with:

```sh
sudo apt install ./syslinuxos-boot-repair_0.3.3_amd64.deb
```

Boot a SysLinuxOS Live USB in the same firmware mode as the installed system.
Open **SysLinuxOS Boot Repair** from **SysLinuxOS Tools** in the applications menu. The GTK interface
runs as the desktop user and asks for administrative authentication when needed
(the Live session normally provides passwordless sudo).

1. Select the installed system partition. The list shows device, size, filesystem,
   label, disk, state and mount locations. Mounted and LUKS partitions stay
   visible, including decrypted Btrfs/ext4/XFS mappings. For a locked LUKS
   partition, enter its passphrase in the graphical unlock dialog, then review
   the plan. Unlocking uses UDisks2 and may request administrative authentication.
   The passphrase is never passed through command arguments or saved to disk.
   Already unlocked or mounted roots can be selected directly.
2. Choose **Inspect only** (the default), **Regenerate the boot menu**, or
   **Reinstall GRUB and regenerate the boot menu**.
3. Click **Review plan**. The helper inspects the installation read-only and shows
   its root, any separate boot partition, firmware and EFI partition. For BIOS,
   the reinstall destination is the whole disk containing the selected root. For
   UEFI, a reinstall also moves the SysLinuxOS entry to the first position of the
   firmware boot order; other entries keep their relative order.
4. Check the devices and click **Confirm repair**. Cancel is the default button.
   Inspection alone never offers a repair confirmation. The interface stays open
   during repairs and shows the result and diagnostic output under **Details**.

The interface and helper default to English and automatically use Italian,
German, French or Spanish according to the Live desktop's locale. Locale order:
`LC_ALL`, `LC_MESSAGES`, then `LANG`, with GNU-style `LANGUAGE` preference when
the locale is not C/POSIX. Other languages fall back to English. This uses the
session language rather than the language of the installed system being repaired.
Low-level GRUB and system-command output retains those tools' own language.

For an explicit language, run `syslinuxos-boot-repair-launcher --language it`.
The launcher opens the GUI; `syslinuxos-boot-repair-launcher --cli` opens the
original interactive workflow in your current terminal. Direct terminal commands
remain available:

```sh
sudo syslinuxos-boot-repair --plan --root /dev/nvme0n1p2
sudo syslinuxos-boot-repair --config --root /dev/nvme0n1p2
sudo syslinuxos-boot-repair --reinstall --root /dev/nvme0n1p2
```

For BIOS installations, add the whole destination disk, such as
`--disk /dev/sda`, to `--reinstall`. For UEFI installations, the EFI System
Partition is found in the installed system's `/etc/fstab`. Separate `/boot`
partitions are also read from there. The helper shows the detected devices and
requires typing an exact confirmation in the terminal before it changes anything.
Type the entire displayed line, including the literal keyword `REPAIR`, in every
language. In the GUI, the explicit confirmation button supplies this same exact
confirmation to the helper; the helper validates the devices again.

`--plan` mounts the selected system read-only. `--config` runs `update-grub` in
the installed system. `--reinstall` first runs `grub-install`, then
`update-grub`. Before either repair, the existing `grub.cfg` is copied to a
`grub.cfg.syslinuxos-backup.*` file in the same directory. The helper does not
install packages, change partition tables, format disks, or restore Btrfs
snapshots.

Supported roots: SysLinuxOS Btrfs with subvolume `@`, ext4, or XFS, either
unencrypted or directly inside a LUKS partition. LVM inside LUKS, RAID, 32-bit
UEFI, nonstandard mount layouts, and other distributions require manual recovery.
Existing mounts are reused through private bind mounts: inspection is read-only
and cleanup removes only the helper's mounts. The user's mounts and unlocked
mapping remain available after completion. The CLI requires unlocking first;
`--root` accepts either the LUKS partition or its open `/dev/mapper/...` device.

The helper checks the selected encrypted container against the installed
`crypttab`, including when the Live mapping name differs from the installed
`luks-UUID` name. It preserves `crypttab`, initramfs, LUKS headers and keyslots.
When `/boot` resides inside the encrypted root it enables
`GRUB_ENABLE_CRYPTODISK=y` through a dedicated GRUB defaults file. Stock GRUB
needs a PBKDF2 keyslot for LUKS2 encrypted `/boot`; incompatible Argon2-only
layouts are rejected before repair, without changing the header. A separate
unencrypted `/boot` avoids that restriction.

SysLinuxOS's `@home`, nested `@/.snapshots`, Snapper configuration and rollback
backups are preserved. The helper operates on the active `@` root and invokes
the installed GRUB scripts, including any snapshot menu integration. It does
not restore snapshots or rerun snapshot setup. Plans and confirmation show the
actual decrypted root and its backing LUKS container. The UEFI Live must be booted in
64-bit UEFI mode so GRUB can register its firmware entry. Back up important data before repairing an installation.

The workflow follows the [Debian GRUB EFI recovery guide](https://wiki.debian.org/GrubEFIReinstall)
and [Debian chroot guidance](https://wiki.debian.org/chroot).
