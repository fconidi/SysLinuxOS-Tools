#!/usr/bin/python3
"""GTK front end; only the installed repair helper receives administrative rights."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import threading

import gi
gi.require_version("Gtk", "3.0")
from gi.repository import Gio, GLib, Gtk

HELPER = "/usr/sbin/syslinuxos-boot-repair"
ACTIONS = (
    ("plan", "Inspect only — no changes"),
    ("config", "Regenerate the boot menu"),
    ("reinstall", "Reinstall GRUB and regenerate the boot menu"),
)


def session_language(env=None):
    env = os.environ if env is None else env
    base = env.get("LC_ALL") or env.get("LC_MESSAGES") or env.get("LANG") or "C"
    if base in ("C", "POSIX") or base.startswith("C."):
        return "en"
    value = (env.get("LANGUAGE") or base).split(":")[0]
    for separator in ("_", ".", "@", "-"):
        value = value.split(separator)[0]
    return value if value in ("it", "de", "fr", "es") else "en"


def load_messages(language):
    catalog = Path(__file__).with_name("translations.json")
    if not catalog.is_file():
        catalog = Path("/usr/share/syslinuxos-boot-repair/translations.json")
    return json.loads(catalog.read_text(encoding="utf-8")).get(language, {})


def partition_inventory(devices):
    """Keep encrypted and mounted roots visible, without treating them as repairable."""
    result = []

    def mountpoints(device):
        paths = [path for path in device.get("mountpoints", []) or [] if path]
        for child in device.get("children", []):
            paths.extend(mountpoints(child))
        return list(dict.fromkeys(paths))

    def visit(device, disk="", encrypted=False):
        kind, fs = device.get("type"), device.get("fstype")
        if kind == "disk":
            disk = device["path"]
        encrypted = encrypted or kind == "crypt" or fs == "crypto_LUKS"
        paths = mountpoints(device)
        if disk and ((kind == "part" and fs in ("btrfs", "ext4", "xfs", "crypto_LUKS"))
                     or (kind == "crypt" and fs in ("btrfs", "ext4", "xfs"))):
            if fs == "crypto_LUKS":
                state = "unlocked" if device.get("children") else "locked"
            elif paths:
                state = "mounted"
            elif encrypted:
                state = "encrypted"
            else:
                state = "ready"
            result.append((device["path"], device.get("size") or "", fs,
                           device.get("label") or "", disk, state, ", ".join(paths)))
        for child in device.get("children", []):
            visit(child, disk, encrypted)

    for device in devices:
        visit(device)
    return result


def candidate_partitions(devices):
    return [row[:5] for row in partition_inventory(devices) if row[5] == "ready"]


PARTITION_STATES = {
    "ready": "Ready",
    "mounted": "Mounted",
    "locked": "Encrypted — locked",
    "unlocked": "Encrypted — unlocked",
    "encrypted": "Encrypted — unlocked",
}


def repair_arguments(root, action, language, disk=""):
    args = [HELPER, "--" + action, "--root", root, "--language", language]
    if disk:
        args += ["--disk", disk]
    return args


def run_helper(args, confirmation=None):
    # Live sessions normally have passwordless sudo. Else let the desktop
    # Polkit agent authenticate. Never run the GTK process as root.
    if os.geteuid() == 0:
        prefix = []
    elif subprocess.run(["sudo", "-n", "true"], capture_output=True).returncode == 0:
        prefix = ["sudo", "-n"]
    else:
        prefix = ["pkexec", "--disable-internal-agent"]
    return subprocess.run(prefix + args, input=(confirmation + "\n") if confirmation else "",
                          text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def unlock_device(device, passphrase):
    """Use the desktop storage service; the secret never enters argv or a file."""
    bus = Gio.bus_get_sync(Gio.BusType.SYSTEM, None)
    objects = bus.call_sync(
        "org.freedesktop.UDisks2", "/org/freedesktop/UDisks2",
        "org.freedesktop.DBus.ObjectManager", "GetManagedObjects", None,
        GLib.VariantType.new("(a{oa{sa{sv}}})"), Gio.DBusCallFlags.NONE, 30000, None,
    ).unpack()[0]
    for path, interfaces in objects.items():
        block = interfaces.get("org.freedesktop.UDisks2.Block", {})
        raw = block.get("Device", [])
        if os.path.realpath(os.fsdecode(bytes(raw).rstrip(b"\0"))) != os.path.realpath(device):
            continue
        if "org.freedesktop.UDisks2.Encrypted" not in interfaces:
            continue
        bus.call_sync(
            "org.freedesktop.UDisks2", path, "org.freedesktop.UDisks2.Encrypted",
            "Unlock", GLib.Variant("(sa{sv})", (passphrase, {})),
            GLib.VariantType.new("(o)"), Gio.DBusCallFlags.ALLOW_INTERACTIVE_AUTHORIZATION, 120000, None,
        )
        return
    raise RuntimeError("LUKS device is not available through UDisks")


class RepairWindow(Gtk.Window):
    def __init__(self, language):
        super().__init__(title="SysLinuxOS Boot Repair")
        self.set_icon_name("syslinuxos-boot-repair")
        source_icon = Path(__file__).with_name("syslinuxos-boot-repair.svg")
        if source_icon.is_file():
            self.set_icon_from_file(str(source_icon))
        self.language = language
        self.messages = load_messages(language)
        self.busy = False
        self.set_default_size(780, 560)
        self.set_border_width(18)
        self.connect("delete-event", lambda *_: self.busy)
        self.connect("destroy", lambda *_: Gtk.main_quit() if Gtk.main_level() else None)
        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=12)
        self.add(box)
        intro = Gtk.Label(label=self.tr("Choose the installed SysLinuxOS partition, then review the plan."))
        intro.set_line_wrap(True)
        intro.set_xalign(0)
        box.pack_start(intro, False, False, 0)
        self.store = Gtk.ListStore(*([str] * 8))
        self.tree = Gtk.TreeView(model=self.store)
        for number, title in enumerate(("Partition", "Size", "Filesystem", "Label", "Disk", "Status", "Mounted at")):
            column = Gtk.TreeViewColumn(self.tr(title), Gtk.CellRendererText(), text=number)
            column.set_resizable(True)
            self.tree.append_column(column)
        scroll = Gtk.ScrolledWindow()
        scroll.set_min_content_height(150)
        scroll.add(self.tree)
        box.pack_start(scroll, True, True, 0)
        self.action = Gtk.ComboBoxText()
        for key, label in ACTIONS:
            self.action.append(key, self.tr(label))
        self.action.set_active_id("plan")
        self.action.get_accessible().set_name(self.tr("Operation"))
        box.pack_start(self.action, False, False, 0)
        self.status = Gtk.Label(xalign=0)
        self.status.set_line_wrap(True)
        self.status.set_selectable(True)
        box.pack_start(self.status, False, False, 0)
        expander = Gtk.Expander(label=self.tr("Details"))
        self.log = Gtk.TextView(editable=False, cursor_visible=False, monospace=True)
        self.log.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        log_scroll = Gtk.ScrolledWindow()
        log_scroll.set_min_content_height(160)
        log_scroll.add(self.log)
        expander.add(log_scroll)
        self.expander = expander
        box.pack_start(expander, True, True, 0)
        buttons = Gtk.ButtonBox(spacing=8)
        self.refresh = Gtk.Button(label=self.tr("Refresh partitions"))
        self.review = Gtk.Button(label=self.tr("Review plan"))
        self.close_button = Gtk.Button(label=self.tr("Close"))
        for button in (self.refresh, self.review, self.close_button):
            buttons.add(button)
        self.refresh.connect("clicked", lambda *_: self.refresh_partitions())
        self.review.connect("clicked", self.on_review)
        self.close_button.connect("clicked", lambda *_: self.destroy())
        box.pack_end(buttons, False, False, 0)
        cmdline = Path("/proc/cmdline").read_text().split()
        self.live = "boot=live" in cmdline
        if self.live:
            self.refresh_partitions()
        else:
            self.status.set_text(self.tr("SysLinuxOS Live is required. Restart from the Live USB to use Boot Repair."))
            self.refresh.set_sensitive(False)
            self.review.set_sensitive(False)

    def tr(self, text):
        return self.messages.get(text, text)

    def refresh_partitions(self):
        self.store.clear()
        try:
            output = subprocess.run(
                ["lsblk", "--json", "--tree", "--paths", "-o", "PATH,TYPE,SIZE,FSTYPE,LABEL,MOUNTPOINTS"],
                text=True, capture_output=True, check=True,
            )
            for row in partition_inventory(json.loads(output.stdout)["blockdevices"]):
                path, size, fs, label, disk, state, mounts = row
                self.store.append((path, size, fs, label, disk,
                                   self.tr(PARTITION_STATES[state]), mounts, state))
            self.status.set_text("" if len(self.store) else self.tr(
                "No Btrfs, ext4, XFS or LUKS partitions found."))
        except (OSError, ValueError, subprocess.CalledProcessError) as error:
            self.status.set_text(str(error))

    def set_busy(self, busy):
        self.busy = busy
        for widget in (self.tree, self.action, self.refresh, self.review, self.close_button):
            widget.set_sensitive(not busy)

    def background(self, work, done):
        self.set_busy(True)

        def run():
            try:
                value, error = work(), None
            except Exception as exc:
                value, error = None, str(exc)
            GLib.idle_add(finish, value, error)

        def finish(value, error):
            self.set_busy(False)
            done(value, error)
            return False

        threading.Thread(target=run, daemon=True).start()

    def on_review(self, *_):
        model, selected = self.tree.get_selection().get_selected()
        if selected is None:
            self.status.set_text(self.tr("Select a partition first."))
            return
        state = model[selected][7]
        if state == "locked":
            self.unlock_selected(model[selected][0])
            return
        root, disk = model[selected][0], model[selected][4]
        action = self.action.get_active_id()
        self.status.set_text(self.tr("Checking the selected installation…"))
        self.log.get_buffer().set_text("")

        def inspect():
            args = repair_arguments(root, "plan", self.language)
            result = run_helper(args + ["--plan-json"])
            if result.returncode:
                raise RuntimeError(result.stdout + result.stderr)
            plan = json.loads(result.stdout)
            target_disk = disk if plan["firmware"] == "bios" and action == "reinstall" else ""
            args = repair_arguments(root, action, self.language, target_disk)
            if action != "plan":
                result = run_helper(args + ["--plan-json"])
                if result.returncode:
                    raise RuntimeError(result.stdout + result.stderr)
                plan = json.loads(result.stdout)
            return plan, args

        def inspected(value, error):
            if error:
                self.status.set_text(self.tr("Unable to inspect the selected installation. No repair performed."))
                self.log.get_buffer().set_text(error)
                self.expander.set_expanded(True)
                return
            plan, args = value
            self.status.set_text(self.tr("The selected installation has been inspected read-only. No changes have been made."))
            self.show_plan(plan, args)

        self.background(inspect, inspected)

    def unlock_selected(self, device):
        dialog = Gtk.Dialog(title=self.tr("Unlock encrypted partition"), transient_for=self, modal=True)
        dialog.add_button(self.tr("Cancel"), Gtk.ResponseType.CANCEL)
        dialog.add_button(self.tr("Unlock"), Gtk.ResponseType.OK)
        dialog.set_default_response(Gtk.ResponseType.CANCEL)
        box = dialog.get_content_area()
        box.set_border_width(18)
        box.set_spacing(12)
        box.pack_start(Gtk.Label(label=device, xalign=0), False, False, 0)
        entry = Gtk.Entry()
        entry.set_visibility(False)
        entry.set_input_purpose(Gtk.InputPurpose.PASSWORD)
        entry.set_placeholder_text(self.tr("Disk passphrase"))
        entry.get_accessible().set_name(self.tr("Disk passphrase"))
        box.pack_start(entry, False, False, 0)
        dialog.show_all()
        entry.grab_focus()
        response = dialog.run()
        password = entry.get_text() if response == Gtk.ResponseType.OK else ""
        entry.set_text("")
        dialog.destroy()
        if not password:
            return
        self.status.set_text(self.tr("Unlocking encrypted partition…"))

        def unlocked(_value, error):
            if error:
                # Storage-service errors are not logged with credential context.
                self.status.set_text(self.tr("Unable to unlock the partition. Check the passphrase and try again."))
                return
            self.refresh_partitions()
            for row in self.store:
                if row[0] == device:
                    self.tree.get_selection().select_iter(row.iter)
                    break
            self.status.set_text(self.tr("Partition unlocked. Review the repair plan to continue."))

        self.background(lambda: unlock_device(device, password), unlocked)

    def show_plan(self, plan, args):
        lines = [
            ("Root partition", plan["root"] + " (" + plan["filesystem"] + ")"),
            ("Boot partition", plan["boot"] or self.tr("No separate partition")),
            ("EFI partition", plan["esp"] or self.tr("Not applicable")),
            ("Firmware", plan["firmware"].upper()),
            ("Operation", self.tr(dict(ACTIONS)[plan["action"]])),
        ]
        if plan.get("crypto"):
            lines.insert(1, ("LUKS container", plan["crypto"]))
        if plan["action"] == "reinstall":
            lines.append(("Bootloader destination", plan["esp"] or plan["disk"]))
        summary = "\n".join(self.tr(key) + ": " + value for key, value in lines)
        dialog = Gtk.Dialog(title=self.tr("Repair plan"), transient_for=self, modal=True)
        dialog.set_default_size(620, 320)
        dialog.add_button(self.tr("Close" if plan["action"] == "plan" else "Cancel"), Gtk.ResponseType.CANCEL)
        if plan["action"] != "plan":
            dialog.add_button(self.tr("Confirm repair"), Gtk.ResponseType.OK)
        dialog.set_default_response(Gtk.ResponseType.CANCEL)
        area = dialog.get_content_area()
        area.set_border_width(18)
        area.set_spacing(16)
        label = Gtk.Label(label=summary, xalign=0)
        label.set_selectable(True)
        area.pack_start(label, True, True, 0)
        note = "The selected installation has been inspected read-only. No changes have been made."
        if plan["action"] != "plan":
            note = "This will modify the boot files of the selected system. Check the root partition and bootloader destination before confirming."
        label = Gtk.Label(label=self.tr(note), xalign=0)
        label.set_line_wrap(True)
        label.set_max_width_chars(65)
        area.pack_start(label, False, False, 0)
        dialog.show_all()
        response = dialog.run()
        dialog.destroy()
        if response == Gtk.ResponseType.OK and plan["action"] != "plan":
            self.status.set_text(self.tr("Repair in progress. Keep this window open."))
            self.expander.set_expanded(True)

            def repaired(result, error):
                failed = error is not None or result.returncode != 0
                self.status.set_text(self.tr(
                    "The operation failed. Review the details below; a repair may have partially completed."
                    if failed else "Repair completed. Remove the Live media and restart."))
                self.log.get_buffer().set_text(error if error else result.stdout + result.stderr)

            self.background(lambda: run_helper(args, plan["confirmation"]), repaired)


def main():
    parser = argparse.ArgumentParser(description="SysLinuxOS Boot Repair")
    parser.add_argument("--language", choices=("en", "it", "de", "fr", "es"))
    args = parser.parse_args()
    window = RepairWindow(args.language or session_language())
    window.show_all()
    Gtk.main()


if __name__ == "__main__":
    main()
