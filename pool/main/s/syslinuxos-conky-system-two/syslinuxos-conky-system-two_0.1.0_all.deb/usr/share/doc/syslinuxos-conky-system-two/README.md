# Conky-System-Two

A transparent desktop monitor for SysLinuxOS and Debian, inspired by the
[MX-Futuriste layout](https://github.com/MX-Linux/mx-conky-data/tree/master/themes/MX-Futuriste)
by Hervé Simonnet.

The monitor combines the installed distribution's logo, a digital clock and
six sections: System, CPU, Memory, Top processes, Storage and Network.
A curved blue rail connects original, modern line icons. Headings are white,
with blue indicators and pale values. The background is fully transparent.

## Install

With the SysLinuxOS APT repository configured:

```sh
sudo apt update
sudo apt install syslinuxos-conky-system-two
```

Or install the downloaded package with APT:

```sh
sudo apt install ./syslinuxos-conky-system-two_0.1.0_all.deb
```

The shared `syslinuxos-conky-menu` dependency supplies the Conky submenu and
launcher icon. It must also be available when installing a downloaded package.

## Use

Open **System Tools > Conky > Start Conky-System-Two** or
**Stop Conky-System-Two**. Italian entries are **Avvia Conky-System-Two** and
**Ferma Conky-System-Two**.

```sh
conky-system-two start
conky-system-two stop
conky-system-two status
```

The panel is centered at the right edge. It is intended as an alternative to
Conky System or Conky Window. The existing themes keep their own controls.

All text, icons, meters, spacing and dimensions scale together to the active
monitor's resolution. Restart after changing the resolution. An optional
manual scale is available:

```sh
CONKY_SYSTEM_TWO_SCALE=1.2 conky-system-two start
```

The distribution is identified through `/etc/os-release`. SysLinuxOS uses its
own logo; Debian uses the Debian logo. Other distributions can provide the
standard `LOGO` icon entry. Logo artwork is loaded from the operating system.
A generic Linux mark is used when no matching logo is installed.

Memory shows RAM usage, available memory and swap separately. The network
section follows the default route and displays local and external IPv4
addresses, transfer rates, totals and ISP. Select a fixed interface with
`CONKY_NET_INTERFACE=enp3s0`. Route changes are detected within ten seconds.

The external IPv4 address is obtained from ipify every five minutes and the
ISP from IPinfo every hour. Requests use HTTPS and three-second timeouts.
Network lookups run in a background thread and use a private cache, keeping
the clock and meters responsive. Unavailable values are shown as `N/A`.

The editable template is `/etc/conky/conky-system-two.conf`; dpkg preserves
edits across upgrades. A compositing window manager provides full alpha
transparency.

## Build

```sh
bash build-deb.sh
```

The package is produced in `dist/`.

## License

Copyright 2026 Franco Conidi. GPL-3.0-or-later; see [LICENSE](LICENSE).
