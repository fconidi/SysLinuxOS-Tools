require('cairo')
if not conky_surface then require('cairo_xlib') end

local BLUE = {0.04, 0.75, 0.97}
local WHITE = {1, 1, 1}
local PALE = {0.82, 0.804, 0.835}
local extents = cairo_text_extents_t:create()
local logo = nil
local anchors = {196, 310, 416, 548, 672, 792}

local function color(cr, rgb, alpha)
    cairo_set_source_rgba(cr, rgb[1], rgb[2], rgb[3], alpha or 1)
end

local function value(expression)
    local text = conky_parse('${' .. expression .. '}') or ''
    text = text:gsub('^%s+', ''):gsub('%s+$', '')
    return text
end

local function number(expression)
    return tonumber(value(expression)) or 0
end

local function text(cr, x, y, content, size, rgb, align, max_width, bold)
    content = tostring(content or 'N/A')
    cairo_select_font_face(cr, 'DejaVu Sans', CAIRO_FONT_SLANT_NORMAL,
                           bold and CAIRO_FONT_WEIGHT_BOLD or CAIRO_FONT_WEIGHT_NORMAL)
    cairo_set_font_size(cr, size or 13)
    cairo_text_extents(cr, content, extents)
    if max_width and extents.x_advance > max_width then
        local characters = {}
        for char in content:gmatch('[%z\1-\127\194-\244][\128-\191]*') do
            characters[#characters + 1] = char
        end
        repeat
            characters[#characters] = nil
            content = table.concat(characters) .. '…'
            cairo_text_extents(cr, content, extents)
        until extents.x_advance <= max_width or #characters == 0
    end
    if align == 'right' then x = x - extents.x_advance end
    if align == 'center' then x = x - extents.x_advance / 2 end
    color(cr, rgb or PALE)
    cairo_move_to(cr, x, y)
    cairo_show_text(cr, content)
end

local function line(cr, x1, y1, x2, y2)
    cairo_move_to(cr, x1, y1)
    cairo_line_to(cr, x2, y2)
end

local function icon(cr, kind, x, y)
    cairo_save(cr)
    cairo_translate(cr, x, y)
    color(cr, WHITE, 0.3)
    cairo_set_line_width(cr, 1)
    cairo_new_path(cr)
    cairo_arc(cr, 0, 0, 19, 0, math.pi * 2)
    cairo_stroke(cr)
    color(cr, WHITE)
    cairo_set_line_width(cr, 1.6)
    if kind == 1 then
        cairo_rectangle(cr, -9, -7, 18, 12)
        line(cr, 0, 5, 0, 9); line(cr, -5, 9, 5, 9)
    elseif kind == 2 then
        cairo_rectangle(cr, -6, -6, 12, 12)
        for p = -4, 4, 4 do
            line(cr, p, -10, p, -6); line(cr, p, 6, p, 10)
            line(cr, -10, p, -6, p); line(cr, 6, p, 10, p)
        end
        cairo_rectangle(cr, -2, -2, 4, 4)
    elseif kind == 3 then
        cairo_rectangle(cr, -10, -6, 20, 12)
        for p = -7, 5, 6 do cairo_rectangle(cr, p, -3, 3, 5) end
        for p = -7, 7, 4 do line(cr, p, 6, p, 9) end
    elseif kind == 4 then
        cairo_move_to(cr, -11, 0); cairo_line_to(cr, -6, 0)
        cairo_line_to(cr, -3, -7); cairo_line_to(cr, 1, 8)
        cairo_line_to(cr, 5, -3); cairo_line_to(cr, 8, 0); cairo_line_to(cr, 11, 0)
    elseif kind == 5 then
        cairo_rectangle(cr, -9, -10, 18, 20)
        line(cr, -6, -4, 6, -4); line(cr, -6, 0, 6, 0)
        cairo_new_sub_path(cr); cairo_arc(cr, 4, 6, 1, 0, math.pi * 2)
    elseif kind == 6 then
        for radius = 5, 13, 4 do
            cairo_new_sub_path(cr)
            cairo_arc(cr, 0, 8, radius, math.pi * 1.22, math.pi * 1.78)
        end
        cairo_new_sub_path(cr); cairo_arc(cr, 0, 7, 1, 0, math.pi * 2)
    end
    cairo_stroke(cr)
    cairo_restore(cr)
end

local function heading(cr, index, title)
    icon(cr, index, 26, anchors[index])
    text(cr, 62, anchors[index] + 5, title, 15, WHITE, nil, 280, true)
end

local function row(cr, y, label, content)
    text(cr, 62, y, label, 12, BLUE)
    text(cr, 342, y, content, 13, PALE, 'right', 228)
end

local function bar(cr, y, percent)
    percent = math.max(0, math.min(100, percent))
    cairo_set_line_width(cr, 4)
    color(cr, BLUE, 0.22); line(cr, 64, y, 292, y); cairo_stroke(cr)
    if percent > 0 then
        color(cr, BLUE); line(cr, 64, y, 64 + 228 * percent / 100, y); cairo_stroke(cr)
    end
    text(cr, 342, y + 4, string.format('%.0f%%', percent), 12, WHITE, 'right')
end

local function data_file()
    local data = {}
    local path = os.getenv('CONKY_SYSTEM_TWO_DATA') or ''
    local handle = io.open(path, 'r')
    if handle then
        for entry in handle:lines() do
            local key, content = entry:match('^([a-z_]+)\t(.*)$')
            if key then data[key] = content end
        end
        handle:close()
    end
    return data
end

local function draw_logo(cr)
    local path = os.getenv('CONKY_SYSTEM_TWO_LOGO') or ''
    if not logo and path ~= '' then
        local image = cairo_image_surface_create_from_png(path)
        if cairo_surface_status(image) == CAIRO_STATUS_SUCCESS then logo = image
        else cairo_surface_destroy(image) end
    end
    if logo then
        local width, height = cairo_image_surface_get_width(logo), cairo_image_surface_get_height(logo)
        local factor = 64 / math.max(width, height)
        cairo_save(cr)
        cairo_translate(cr, 180 - width * factor / 2, 8)
        cairo_scale(cr, factor, factor)
        cairo_set_source_surface(cr, logo, 0, 0); cairo_paint(cr)
        cairo_restore(cr)
    else
        color(cr, BLUE); cairo_set_line_width(cr, 2)
        cairo_arc(cr, 180, 40, 27, 0, math.pi * 2); cairo_stroke(cr)
        text(cr, 180, 48, 'L', 25, WHITE, 'center')
    end
end

function conky_draw()
    if not conky_window or conky_window.width <= 0 then return end
    local surface, owned
    if conky_surface then surface = conky_surface(); owned = false
    else
        surface = cairo_xlib_surface_create(conky_window.display, conky_window.drawable,
                                             conky_window.visual, conky_window.width, conky_window.height)
        owned = true
    end
    if not surface then return end
    local cr = cairo_create(surface)
    cairo_scale(cr, conky_window.width / 360, conky_window.width / 360)
    cairo_set_line_cap(cr, CAIRO_LINE_CAP_ROUND)
    color(cr, BLUE, 0.75); cairo_set_line_width(cr, 1.4)
    for index = 1, #anchors - 1 do
        local first, last = anchors[index] + 21, anchors[index + 1] - 21
        cairo_move_to(cr, 26, first)
        cairo_curve_to(cr, 56, first + (last-first)/3, -4, last - (last-first)/3, 26, last)
        cairo_stroke(cr)
    end
    local data = data_file()
    draw_logo(cr)
    text(cr, 180, 92, data.brand or 'Linux', 14, WHITE, 'center', 300, true)
    text(cr, 94, 128, os.date('%H'), 39, WHITE, 'center')
    text(cr, 116, 173, os.date('%M'), 39, BLUE, 'center')
    text(cr, 186, 130, os.date('%A'), 14, WHITE, nil, 148)
    text(cr, 186, 153, os.date('%d %b %Y'), 13, BLUE, nil, 148)

    heading(cr, 1, 'System')
    text(cr, 62, 224, data.os_name or 'Linux', 12, PALE, nil, 280)
    row(cr, 244, 'Kernel', value('kernel'))
    row(cr, 264, 'Uptime', value('uptime_short'))
    row(cr, 284, 'Processes', value('processes') .. ' / ' .. value('running_processes') .. ' running')

    heading(cr, 2, 'CPU')
    text(cr, 62, 337, data.cpu_model or 'Processor', 12, PALE, nil, 280)
    text(cr, 62, 357, value('freq_g') .. ' GHz', 13, PALE)
    text(cr, 342, 357, data.cpu_temp or 'N/A', 13, PALE, 'right')
    bar(cr, 374, number('cpu'))
    text(cr, 62, 396, 'Load  ' .. value('loadavg'), 12, BLUE)

    heading(cr, 3, 'Memory')
    row(cr, 444, 'RAM', value('mem') .. ' / ' .. value('memmax'))
    bar(cr, 458, number('memperc'))
    row(cr, 479, 'Available', value('memeasyfree'))
    row(cr, 499, 'Swap', value('swap') .. ' / ' .. value('swapmax'))
    bar(cr, 513, number('swapperc'))

    heading(cr, 4, 'Top processes')
    text(cr, 286, 577, 'CPU%', 10, BLUE, 'right')
    text(cr, 342, 577, 'MEM%', 10, BLUE, 'right')
    for index = 1, 3 do
        local y = 596 + (index - 1) * 20
        text(cr, 62, y, value('top name ' .. index), 13, PALE, nil, 172)
        text(cr, 286, y, value('top cpu ' .. index), 12, WHITE, 'right')
        text(cr, 342, y, value('top mem ' .. index), 12, PALE, 'right')
        color(cr, WHITE, 0.13); cairo_set_line_width(cr, 0.6)
        line(cr, 62, y + 6, 342, y + 6); cairo_stroke(cr)
    end

    heading(cr, 5, 'Storage')
    row(cr, 701, 'Root', value('fs_used /') .. ' / ' .. value('fs_size /'))
    bar(cr, 715, number('fs_used_perc /'))
    row(cr, 739, 'Home', value('fs_used /home') .. ' / ' .. value('fs_size /home'))
    bar(cr, 753, number('fs_used_perc /home'))
    text(cr, 62, 774, 'I/O  ' .. value('diskio_read') .. ' read / ' .. value('diskio_write') .. ' write', 11, BLUE, nil, 280)

    heading(cr, 6, 'Network')
    local interface = data.interface or ''
    if interface:match('^[%w_.:-]+$') and #interface <= 15 then
        row(cr, 820, interface, data.local_ip or 'N/A')
        text(cr, 62, 841, '↓ ' .. value('downspeed ' .. interface) .. '/s', 13, PALE)
        text(cr, 342, 841, '↑ ' .. value('upspeed ' .. interface) .. '/s', 13, PALE, 'right')
        text(cr, 62, 862, 'Total  ↓ ' .. value('totaldown ' .. interface) .. '  ↑ ' .. value('totalup ' .. interface), 12, BLUE, nil, 280)
    else text(cr, 62, 820, 'Offline', 13, PALE) end
    row(cr, 885, 'External IP', data.public_ip or 'N/A')
    row(cr, 907, 'ISP', data.isp or 'N/A')

    cairo_destroy(cr)
    if owned then cairo_surface_destroy(surface) end
end

function conky_release()
    if logo then cairo_surface_destroy(logo); logo = nil end
    if extents then cairo_text_extents_t:destroy(extents); extents = nil end
end
