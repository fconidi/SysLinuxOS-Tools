#!/bin/bash

# Verifica il numero di CPU sul sistema
cpu=$(grep -c processor /proc/cpuinfo)

# Verifica se il file di configurazione esiste
if [ -f /opt/Sys-ring-conky/settings.lua ]; then
  # Sostituisce la riga "cpu_cores = 0" con il numero di CPU rilevate
  sed -i "s/cpu_cores = [0-9]\+/cpu_cores = $cpu/" /opt/Sys-ring-conky/settings.lua
  echo "Impostazioni di CPU cores aggiornate con successo."
else
  echo "Il file di configurazione non esiste."
fi
