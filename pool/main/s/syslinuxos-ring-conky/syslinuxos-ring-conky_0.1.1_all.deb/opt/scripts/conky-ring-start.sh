#!/bin/bash

cd /opt/Sys-ring-conky/
conky -c conkyrc &
