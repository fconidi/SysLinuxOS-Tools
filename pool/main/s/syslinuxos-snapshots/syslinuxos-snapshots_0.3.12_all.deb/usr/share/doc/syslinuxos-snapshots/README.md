# SysLinuxOS Snapshots

Meta-package that integrates **snapper**, **grub-btrfs** and the **syslinuxos-rollback** helper to provide a snapshot+rollback workflow on SysLinuxOS btrfs systems.

## How it works

On a SysLinuxOS installation with btrfs, the package automatically configures:

- **snapper** creates snapshots of the `@` subvolume (the rootfs) before/after every `apt install/upgrade`, and daily via timer. Retention: latest 3 timeline snapshots + latest 3 number-limited.
- **grub-btrfs** scans `.snapshots/` with inotify and adds the latest 3 snapshots to the GRUB menu (submenu "SysLinuxOS — snapshots").
- **syslinuxos-rollback** performs the rollback on a Debian-style layout (required because upstream `snapper rollback` only works on openSUSE-style layouts).

## Recovery workflow

To restore the system to a previous state:

1. **Reboot.** From the GRUB menu pick `Advanced options` (or equivalent) → open **SysLinuxOS — snapshots**.
2. Select the desired snapshot. Boot it.
3. The system reaches a **recovery console** (rootfs is read-only, so the display manager fails — this is expected). Log in with your user.
4. Run:
   ```bash
   sudo syslinuxos-rollback
   ```
   The script auto-detects the snapshot you booted from. Confirm with `y`.
5. `sudo reboot`. The system now boots normally from the rolled-back subvolume.

## Recovery from a recovery

The rollback does NOT delete the previous system: it preserves it as the btrfs subvolume `@.rollback-bak-<TIMESTAMP>`. If you need to revert, mount the btrfs top-level from a live ISO and swap:

```bash
sudo mount -o subvolid=5 /dev/<ROOT> /mnt/btrfs
sudo btrfs subvolume delete /mnt/btrfs/@        # delete the rolled-back @ (careful)
sudo mv /mnt/btrfs/@.rollback-bak-<TS> /mnt/btrfs/@
sudo umount /mnt/btrfs
```

## Removing a post-rollback backup

Once the rollback is confirmed good, you can free space:

```bash
sudo mkdir -p /mnt/btrfs
sudo mount -o subvolid=5 /dev/<ROOT> /mnt/btrfs
# The backup carries the previous snapper history as nested subvolumes, so a
# plain delete fails with "Directory not empty". Use -R to delete recursively
# (nested snapshots first), -c to commit and free the space immediately.
sudo btrfs subvolume delete -R -c /mnt/btrfs/@.rollback-bak-<TS>
sudo umount /mnt/btrfs
```

## What this package does NOT do

- It does nothing if the rootfs is not btrfs (postinst prints a warning).
- It does not handle traditional backups (rsync etc.): use `distroclone-backup` for that.
- It does not encrypt snapshots: they use the same encryption as the underlying filesystem.

## Installed files

| Path | Purpose |
|------|---------|
| `/usr/bin/syslinuxos-rollback` | Rollback helper for Debian-style btrfs layout |
| `/usr/sbin/syslinuxos-snapshots-setup` | Idempotent setup script (invoked by postinst and Calamares) |
| `/etc/grub.d/13_syslinuxos-btrfs-otheros` | Detect other btrfs+@ Linux installs (os-prober workaround) |
| `/etc/grub.d/14_syslinuxos-snapshots-otheros` | "Advanced" submenu chainloading snapshots of other SysLinuxOS installs |
| `/usr/share/doc/syslinuxos-snapshots/README.md` | This documentation |

The package also configures (in postinst):

- snapper config `root` (if missing): NUMBER_LIMIT=5, TIMELINE_DAILY=7
- `/etc/default/grub-btrfs/config`: SUBMENUNAME="SysLinuxOS — snapshots", LIMIT=8
- `grub-btrfsd.service`: enabled + started
- `snapper-timeline.timer` + `snapper-cleanup.timer`: enabled + started

## Uninstall

```bash
sudo apt remove syslinuxos-snapshots
```

Removes the helper and disables services, **but does NOT delete existing snapshots** nor the snapper config. For a full cleanup:

```bash
sudo apt purge syslinuxos-snapshots
sudo rm -rf /etc/snapper/configs/root
sudo snapper -c root delete --sync 1-99  # optional: delete all snapshots
```
