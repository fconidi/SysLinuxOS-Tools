# syslinuxos-snapshot-recovery.sh
# Shown at login ONLY when the system is booted from a snapshot
# (a read-only recovery environment). Reminds the user how to roll back.
# Sourced by login shells from /etc/profile; safe no-op on normal boots.

_slos_is_snapshot_boot() {
    # The booted root subvolume of a snapshot lives under /.snapshots/
    # (e.g. subvol=/@/.snapshots/7/snapshot). Normal boots use subvol=/@.
    case "$(findmnt -rno OPTIONS / 2>/dev/null)" in
        *subvol=*/.snapshots/*) return 0 ;;
    esac
    # Fallback on the kernel command line if findmnt is unavailable.
    case " $(cat /proc/cmdline 2>/dev/null) " in
        *.snapshots/*) return 0 ;;
    esac
    return 1
}

if _slos_is_snapshot_boot; then
    cat <<'EOF'

======================================================================
  MODALITA SNAPSHOT  /  SNAPSHOT MODE   (sola lettura / read-only)
......................................................................
  Stai usando un'istantanea di sistema per il recupero.
  You are running a system snapshot for recovery.

  Per ripristinare il sistema a questo stato / To roll back, run:

        sudo syslinuxos-rollback
        sudo reboot
======================================================================

EOF
fi

unset -f _slos_is_snapshot_boot
