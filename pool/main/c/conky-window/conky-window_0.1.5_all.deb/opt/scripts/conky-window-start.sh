#!/bin/bash

REF_W=1920
REF_H=1080
CONF_SRC=/etc/conky/conky-window.conf
CONF_TMP=/tmp/conky-window-scaled.conf

# Detect current screen resolution
SCREEN_W=""
SCREEN_H=""
if command -v xrandr >/dev/null 2>&1; then
    RES=$(xrandr 2>/dev/null | grep '\*' | head -1 | awk '{print $1}')
    SCREEN_W=${RES%x*}
    SCREEN_H=${RES#*x}
fi
if [ -z "$SCREEN_W" ] && command -v xdpyinfo >/dev/null 2>&1; then
    RES=$(xdpyinfo 2>/dev/null | grep 'dimensions' | awk '{print $2}')
    SCREEN_W=${RES%x*}
    SCREEN_H=${RES#*x}
fi
SCREEN_W=${SCREEN_W:-$REF_W}
SCREEN_H=${SCREEN_H:-$REF_H}

# Scale factor: min(W/REF_W, H/REF_H). Override: CONKY_WINDOW_SCALE=<factor>
if [ -n "$CONKY_WINDOW_SCALE" ]; then
    SCALE=$CONKY_WINDOW_SCALE
else
    SCALE=$(awk -v w="$SCREEN_W" -v h="$SCREEN_H" -v rw="$REF_W" -v rh="$REF_H" \
        'BEGIN { sx=w/rw; sy=h/rh; s=(sx<sy)?sx:sy; printf "%.4f", s }')
fi

# Scale integer value with minimum floor
scale_val() {
    local orig=$1 min=${2:-1}
    awk -v s="$SCALE" -v orig="$orig" -v mn="$min" \
        'BEGIN { v=int(orig*s+0.5); if(v<mn)v=mn; print v }'
}

F16=$(scale_val 16 8)
F12=$(scale_val 12 7)
F10=$(scale_val 10 7)
MIN_W=$(scale_val 300 150)
GAP_Y=$(scale_val 30 10)
GH=$(scale_val 30 15)
GW150=$(scale_val 150 75)
GW180=$(scale_val 180 90)
CBAR_H=$(scale_val 8 4)
CBAR_W=$(scale_val 128 60)     # single-column bar width
CBAR_W2=$(scale_val 88 42)     # two-column bar width (narrower)
GOTO_MID=$(scale_val 155 78)   # goto pixel for column 2

# Adaptive layout based on CPU count:
#   <=6  → single column + TOP 3
#   7-12 → two columns  + TOP 2
#   >12  → two columns  + TOP 1
NCPU=$(nproc)

if [ "$NCPU" -le 6 ]; then
    TOP_N=3
elif [ "$NCPU" -le 12 ]; then
    TOP_N=2
else
    TOP_N=1
fi

# Generate CPU bar lines
CPU_BARS_FILE=$(mktemp)
if [ "$NCPU" -le 6 ]; then
    for i in $(seq 1 "$NCPU"); do
        echo "\${color 6699dd}${i}\${color} \${cpubar ${CBAR_H},${CBAR_W} cpu${i}} \${alignr}\${cpu cpu${i}}%" \
            >> "$CPU_BARS_FILE"
    done
else
    HALF=$(( (NCPU + 1) / 2 ))
    for i in $(seq 1 "$HALF"); do
        j=$((i + HALF))
        if [ "$j" -le "$NCPU" ]; then
            printf "\${color 6699dd}%d\${color} \${cpubar %d,%d cpu%d} \${cpu cpu%d}%%\${goto %d}\${color 6699dd}%d\${color} \${cpubar %d,%d cpu%d} \${cpu cpu%d}%%\n" \
                "$i" "$CBAR_H" "$CBAR_W2" "$i" "$i" "$GOTO_MID" \
                "$j" "$CBAR_H" "$CBAR_W2" "$j" "$j" >> "$CPU_BARS_FILE"
        else
            printf "\${color 6699dd}%d\${color} \${cpubar %d,%d cpu%d} \${cpu cpu%d}%%\n" \
                "$i" "$CBAR_H" "$CBAR_W2" "$i" "$i" >> "$CPU_BARS_FILE"
        fi
    done
fi

# Generate TOP rows
TOP_ROWS_FILE=$(mktemp)
for i in $(seq 1 "$TOP_N"); do
    printf "\${top name %d} \${alignr}\${top cpu %d}%%  \${top mem %d}%%\n" \
        "$i" "$i" "$i" >> "$TOP_ROWS_FILE"
done

# Step 1: inject CPU bars and TOP rows in place of placeholders
awk -v bars="$CPU_BARS_FILE" -v top="$TOP_ROWS_FILE" '
/__CPU_BARS__/ {
    while ((getline line < bars) > 0) print line
    close(bars); next
}
/__TOP_ROWS__/ {
    while ((getline line < top) > 0) print line
    close(top); next
}
{ print }
' "$CONF_SRC" > "${CONF_TMP}.tmp"
rm -f "$CPU_BARS_FILE" "$TOP_ROWS_FILE"

# Step 2: apply scaling (placeholder trick avoids chained replacements)
sed \
    -e "s/size=16/__SZ16__/g" \
    -e "s/size=12/__SZ12__/g" \
    -e "s/size=10/__SZ10__/g" \
    -e "s/__SZ16__/size=${F16}/g" \
    -e "s/__SZ12__/size=${F12}/g" \
    -e "s/__SZ10__/size=${F10}/g" \
    -e "s/minimum_width = 300/minimum_width = ${MIN_W}/" \
    -e "s/gap_y = 30/gap_y = ${GAP_Y}/" \
    -e "s/30,150/${GH},${GW150}/g" \
    -e "s/30,180/${GH},${GW180}/g" \
    "${CONF_TMP}.tmp" > "$CONF_TMP"
rm -f "${CONF_TMP}.tmp"

conky --daemonize --pause=1 --config "$CONF_TMP"
