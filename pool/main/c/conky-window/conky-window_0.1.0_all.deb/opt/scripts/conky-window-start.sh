#!/bin/bash

conky --daemonize --pause=1 --config /etc/conky/conky.conf
