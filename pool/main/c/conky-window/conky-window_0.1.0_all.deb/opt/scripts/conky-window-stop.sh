#!/bin/bash

PID=$(ps aux | grep "/usr/bin/conky" | grep -v "conkyrc" | grep -v "grep" | awk '{print $2}')

if [ -n "$PID" ]; then
    kill $PID
    echo "conky-window stopped (PID $PID)"
else
    echo "conky-window: no running instance found"
fi
