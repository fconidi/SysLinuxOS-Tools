#!/bin/bash

REF_W=1920
REF_H=1080
CONF_SRC=/etc/conky/conky.conf
CONF_TMP=/tmp/conky-window-scaled.conf

# Detect current screen resolution
SCREEN_W=""
SCREEN_H=""
if command -v xrandr >/dev/null 2>&1; then
    RES=$(xrandr 2>/dev/null | grep '\*' | head -1 | awk '{print $1}')
    SCREEN_W=${RES%x*}
    SCREEN_H=${RES#*x}
fi
if [ -z "$SCREEN_W" ] && command -v xdpyinfo >/dev/null 2>&1; then
    RES=$(xdpyinfo 2>/dev/null | grep 'dimensions' | awk '{print $2}')
    SCREEN_W=${RES%x*}
    SCREEN_H=${RES#*x}
fi
SCREEN_W=${SCREEN_W:-$REF_W}
SCREEN_H=${SCREEN_H:-$REF_H}

# Scale factor: min(W/REF_W, H/REF_H). Override: CONKY_WINDOW_SCALE=<factor>
if [ -n "$CONKY_WINDOW_SCALE" ]; then
    SCALE=$CONKY_WINDOW_SCALE
else
    SCALE=$(awk -v w="$SCREEN_W" -v h="$SCREEN_H" -v rw="$REF_W" -v rh="$REF_H" \
        'BEGIN { sx=w/rw; sy=h/rh; s=(sx<sy)?sx:sy; printf "%.4f", s }')
fi

# Scale integer value with minimum floor
scale_val() {
    local orig=$1 min=${2:-1}
    awk -v s="$SCALE" -v orig="$orig" -v mn="$min" \
        'BEGIN { v=int(orig*s+0.5); if(v<mn)v=mn; print v }'
}

F16=$(scale_val 16 8)
F12=$(scale_val 12 7)
F10=$(scale_val 10 7)
MIN_W=$(scale_val 300 150)
GAP_Y=$(scale_val 30 10)
GH=$(scale_val 30 15)
GW150=$(scale_val 150 75)
GW180=$(scale_val 180 90)

# Generate scaled config.
# Placeholder trick (SZ16/SZ12/SZ10) avoids chained replacements when
# scaled values coincide with other original sizes (e.g. size=12 -> size=10).
sed \
    -e "s/size=16/__SZ16__/g" \
    -e "s/size=12/__SZ12__/g" \
    -e "s/size=10/__SZ10__/g" \
    -e "s/__SZ16__/size=${F16}/g" \
    -e "s/__SZ12__/size=${F12}/g" \
    -e "s/__SZ10__/size=${F10}/g" \
    -e "s/minimum_width = 300/minimum_width = ${MIN_W}/" \
    -e "s/gap_y = 30/gap_y = ${GAP_Y}/" \
    -e "s/30,150/${GH},${GW150}/g" \
    -e "s/30,180/${GH},${GW180}/g" \
    "$CONF_SRC" > "$CONF_TMP"

conky --daemonize --pause=1 --config "$CONF_TMP"
