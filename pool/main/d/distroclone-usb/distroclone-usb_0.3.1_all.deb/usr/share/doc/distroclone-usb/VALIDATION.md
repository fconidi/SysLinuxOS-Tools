# Validation — 0.3.0, 2026-10-13

## User physical tests — 2026-10-14

The user reported that physical distroClone USB tests completed successfully
(“è tutto ok”). No individual firmware or encryption cases were specified.
The only requested change is to capitalize the menu entry as DistroClone USB.

## Mandatory test storage rule — 2026-10-14

All future heavy tests and VMs must use the host's local cache, outside Nextcloud
and other synchronized folders: `~/.cache/distroclone-usb/`. Keep the working
directory, temporary files (`TMPDIR`), VM disks, snapshots, writable firmware,
rootfs, logs and screenshots there. Resolve symlinks before starting.
Use `~/.cache/distroclone-usb/.test-artifacts/` when a harness requires that name.
Git exclusions do not prevent Nextcloud synchronization. The `.test-artifacts`
paths below are historical evidence references, not approved output locations
inside the repository. No new heavy tests or VMs were run for this rule update.

## Quick creation and cancellation

- 51 unit tests pass. Added coverage for 12-character acceptance / 11-character
  rejection, open control pipes, queued cancellation after the password line,
  abandoned desktop input, active subprocess interruption and deferred cleanup.
- Cancelled cryptsetup-open and mount operations are tracked when their kernel
  operation succeeded before command exit, so cleanup still owns those resources.
- A dedicated cancellation exception avoids subprocess/select retrying a
  cancellation as a harmless InterruptedError/EINTR.
- Cleanup defers new cancellation until unmount/close operations finish. Failures
  remain errors and are not presented as successful cancellation.
- GTK passes EN/IT/ES/FR/DE, 12-character full mode, Cancel sensitivity, cancellation
  queued before the writer is ready, and cancelled status after completion.

The actual SysLinuxOS 13.2 MATE ISO was used in a disposable 9 GiB QEMU USB guest.
The helper received its secret and controls through the production --control-stdin
protocol. Cancellation at ISO copying returned status 2 and event cancelled;
all helper mounts and crypt mappings were gone (DCUSB_CANCEL_CLEANUP_PASS).
The same virtual USB was then recreated successfully with a 12-character phrase.
A sentinel in the unused pre-partition gap survived creation, proving the former
whole-device clearing did not run (DCUSB_QUICK_FORMAT_12_CHAR_PASS).
The normal ISO SHA-256 copy verification and wrong-key rejection on both LUKS
volumes passed. BIOS boot wrote Shared and system markers; UEFI verified them
after reboot with the same 12-character phrase.

The raw scan checks that NEW private markers and the test phrase are not exposed.
It deliberately does not claim previous plaintext is erased: the quick-reuse
sentinel remains in unused sectors by design. Quick formatting is not secure
erasure. Historical whole-device-clearing tests below apply to 0.2 only.

Evidence: .test-artifacts/create-quick-cancel.log, bios-quick-cancel-write.log,
uefi-quick-cancel-read.log, usb-quick-cancel.img and ui-0.3/desktop.png.
Boot probes for this fixture use --short-test-key; previous fixtures retain their
longer test phrase. No physical USB writes were performed during these tests.
The user's existing physical creation was stopped by SIGTERM at their explicit
request; its PID was confirmed gone and the physical USB is incomplete.

## Historical 0.2.1 validation — 2026-10-13

## Current automated and desktop checks

- 43 unit tests pass, including passphrase rules and private stdin transport,
  command logging, LUKS cleanup, sector initialization, preserved initramfs ORDER,
  rejection of symlinked ORDER files, shared directory permissions and skeleton.
- All five catalogs, format placeholders, localized helper errors and generated
  encrypted GRUB menus (including selected boot language) pass validation.
- GTK workflow passes explicit selection, capacity, matching phrases, disabled
  invalid encryption, mode preservation and phrase clearing on language changes,
  confirmation cancellation and busy state in EN/IT/ES/FR/DE.
- Debian build, Debian-profile Lintian, desktop entry and polkit XML checks pass.
  No test console/probe is included in the package.
- The real MateMenu parser resolves the staged desktop entry inside SysLinuxOS
  Tools using the installed SysLinuxOS MATE menu and the packaged XDG merge file.
  The host menu was not modified during this check.

## Actual SysLinuxOS 13.2 MATE creation and boot

The source ISO and SHA-256 are the same as in the historical validation below.
The privileged writer created three disposable 9 GiB QEMU USB images with
2 GiB persistence. Source disk and workspace were read-only, networking disabled,
and no physical disk was passed through. All modes completed creation, verified
ISO SHA-256 and unmounted filesystems/closed their own encrypted mappings.

| Mode | BIOS | UEFI after BIOS | Shared and system persistence |
|---|---|---|---|
| None | Write succeeded | Read succeeded | Host Shared file readable as admin; live Shared file and /var/lib marker survived |
| Persistence encrypted | Write succeeded after Linux unlock | Read succeeded after Linux unlock | Same checks passed on decrypted persistence |
| Full (ISO + persistence) | Write succeeded after GRUB and Linux unlock | Read succeeded after both unlocks | Same checks passed, including decrypted ISO discovery |

The tests boot the real live initramfs and systemd to multi-user mode. A root-owned,
**test-only** service runs file and permission checks after the Shared service,
prints split markers, syncs and reboots the guest. Initial serial-shell probes
were replaced by this automatic service because interactive UART input was
unreliable. Production boot configuration has no test service or root console.
The UEFI read checks require both files written by BIOS and successful Shared
service activation; they do not merely detect a boot menu.

Wrong passwords were rejected by cryptsetup on each encrypted volume after
creation. A BIOS boot with three wrong Linux unlock attempts reached the explicit
failure stop without reaching a persistent test session. The test passphrase is
fixed fixture data, never a user passphrase. Raw encrypted image scans verify
LUKS headers and absence of the fixture passphrase, host Shared marker and saved
system marker from every logical byte of each encrypted-mode test image.

The supplementary initrd preserves the ISO's original init-premount ORDER and
adds its unlock script before live media discovery. Full mode explicitly selects
/dev/mapper/dcusb_data because live-boot's automatic media scan excludes dm nodes.
The final hardened capability/ORDER preflight also passed against the real ISO.

## Evidence and limits

Evidence remains in .test-artifacts outside Git:
create-0.2-none.log, create-0.2-persistence-final.log,
create-0.2-all-verified.log, bios-none-write.log, bios-persistence-write.log,
bios-all-write-automatic.log, uefi-none-read-automatic.log,
uefi-persistence-read-automatic.log, uefi-all-read-automatic.log,
bios-persistence-reject-automatic.log and usb-0.2-*.img.

Reproduce tests with build_guest.py, guest_create.py and boot_probe.py.
guest_probe_setup.py installs only the automatic test probe in an existing
**disposable virtual image**; it does not change production encryption or boot
configuration. check_image_privacy.py performs read-only raw image checks.
Do not distribute test images: they contain privileged testing instrumentation.

These are VM tests, not physical encrypted USB/firmware or complete desktop
application-installation tests. Ubuntu/Mint encryption is rejected and their
unencrypted real ISO boots remain pending. Secure Boot remains unsupported.
The existing physical USB with four .deb files was not modified.

## Historical 0.1 validation — 2026-10-13

## Automated and desktop checks
- 28 unittest cases pass: device selection, replacement identity, source location,
  mounted/swap/mapper rejection, 512/4096-byte layout alignment, ISO parsing and
  SHA-256, failure propagation, cleanup and destination symlink rejection.
- Real small ISO fixtures generated with xorriso exercise both Debian and casper
  extraction, configuration parsing and digest generation.
- All EN/IT/ES/FR/DE catalogs have the same keys and format placeholders.
  Localized helper rejections and generated GRUB syntax pass in all five languages.
- The real GTK window was exercised on the host desktop: empty state, explicit
  device selection, insufficient capacity, confirmation cancellation, busy state
  and language switching while preserving ISO, disk and size.
- Debian package built; desktop-file validation, XML parsing and Debian-profile
  Lintian pass. Package files are installed as root:root by dpkg-deb.

## Actual SysLinuxOS ISO and disposable USB
Source: `SysLinuxOS-13.2-MATE.iso`, 5,177,106,432 bytes.

SHA-256: `a9956a784a8a3830c483ba3f34421de7d18b9a97751a061b524c2847716233f3`.

An isolated QEMU/KVM guest ran the actual privileged helper against its sole
9 GiB emulated USB disk, requesting 2 GiB persistence. The ISO source was on a
separate read-only virtual ext4 disk; project source was shared read-only.
No physical disk was passed through and the guest had no network.
The production device checks were used unchanged: QEMU's USB disk is a genuine
USB block device inside the guest. Partitioning, formatting, ISO copying,
source/destination verification, both bootloader installations and unmounting
all completed successfully (`DCUSB_GUEST_CREATE_PASS`).

For boot probes only, the disposable USB's GRUB configuration was augmented with
`console=ttyS0,115200 init=/bin/sh`, allowing a serial root shell without desktop
automation. These options are **not** present in production boot configuration.

1. SeaBIOS boot: real live-boot found the ISO; `/` used an overlay with
   `/run/live/persistence/sda4/rw` as its upper layer. A file was written and synced
   under `/var/lib` (`DCUSB_WRITE_OK`).
2. A second SeaBIOS boot read that file unchanged (`DCUSB_PERSIST_OK`).
3. OVMF UEFI boot from `EFI/BOOT/BOOTX64.EFI` read the same file unchanged
   (`DCUSB_PERSIST_OK`). Secure Boot was disabled.

This verifies boot and persistence through the real ISO's live initramfs. It does
not represent a complete guest desktop test or a test on physical firmware/USBs.

## Local evidence and reproduction
Generated evidence is under `.test-artifacts/` and deliberately excluded from Git:
`create-guest-final.log`, `bios-write.log`, `bios-read.log`, `uefi-read.log`,
`syslinuxos-usb.img`, and `ui-multilang/desktop.png`.
The documented screenshot uses the real ISO and a simulated USB selection.

```bash
/usr/bin/python3 -m unittest discover -s tests -v
/usr/bin/python3 tests/gtk_workflow.py --output "$HOME/.cache/distroclone-usb/.test-artifacts/ui" --iso /path/to/live.iso
bash build-deb.sh
lintian --profile debian dist/distroclone-usb_0.1.0_all.deb
```

`tests/build_guest.py` creates the root test environment from a Debian 13 host's
Python/GRUB/tools and the selected host kernel modules. `tests/guest_create.py`
runs the helper in that guest. `tests/boot_probe.py` tests only existing images
under `.test-artifacts/`, with network disabled and no physical disk passthrough.
`tests/integration_usb.py` is an alternative root-only loop-device harness; it was
not run on the host because passwordless sudo was unavailable.

## Remaining compatibility validation
- Real Ubuntu and Linux Mint ISOs (including release-specific casper labels).
- Physical BIOS/UEFI hardware and USB controllers.
- Full live desktop sessions after installing extra applications.
- Secure Boot and MX/antiX are unsupported in 0.1 and are not claimed as tested.
